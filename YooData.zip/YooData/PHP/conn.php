<?php
$varEmpName = $_POST['varEmpName']; 
$varCurClient = $_POST['varCurClient']; 
$varType = $_POST['varType']; 
$varBadge = $_POST['varBadge']; 

/*#This is important*/
require_once(__DIR__ . '/../podio-php-4.3.0/PodioAPI.php');
$client_id = "plugin";
$client_secret = "4zPdYzs9UEfPRPRXqJm9Y82GBejO07DVoNNduhMbNzIdmqPs7zbQnl2GRb4vcrQp";
Podio::setup($client_id, $client_secret);
/*#End of important*/

$app_id = '22959992';
$app_token = '8f513aeaf26f4c60a1d1fa42acdc2ad6';
try {

    Podio::setup($client_id, $client_secret);
    Podio::authenticate_with_app($app_id, $app_token);

    $attributes = array('fields' =>

    array(

        "employeename" => ucwords($varEmpName),

        "current-client" => $varCurClient,

        "typeofwork" => (int)$varType,

        // "date-and-time" => $varDT,

        "badge-counter" => $varBadge
    ));

    PodioItem::create($app_id, $attributes, array());



    // $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // // set the PDO error mode to exception
    // $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // // begin the transaction
    // $conn->beginTransaction();
    // // our SQL statements
    // $conn->exec('INSERT INTO tbl_main VALUES ("' . $varEmpName . '","' . $varCurClient . '","' . $varType . '","' . $varDT . '","' . $varBadge . '")');


    // // commit the transaction
    // $conn->commit();
    // exec("wmic /node:$_SERVER[REMOTE_ADDR] COMPUTERSYSTEM Get UserName", $user);
    // echo($user[1]);

    // echo "New records created successfully";
} catch (PDOException $e) {
    // roll back the transaction if something failed
    // $conn->rollback();
    // echo "Error: " . $e->getMessage();
}

$conn = null;

 