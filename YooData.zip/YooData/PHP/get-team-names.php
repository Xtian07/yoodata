<?php
$longString = "";
$shortString = "";
/*variables coming from Client JS */
// $varUname = $_POST['strUname'];
// $varPword = $_POST['strPword'];
// $varSentUname = "alex Luartes";
$varSentUname = $_POST['varEmpName'];

$varUname = 'xtian@yoonet.com.ph';
$varPword = '8x6e`aFb/F';

/*#This is important*/
require_once (__DIR__.'/../podio-php-4.3.0/PodioAPI.php');
$client_id = "plugin";
$client_secret = "4zPdYzs9UEfPRPRXqJm9Y82GBejO07DVoNNduhMbNzIdmqPs7zbQnl2GRb4vcrQp";
Podio::setup($client_id, $client_secret);
/*#End of important*/
try
{
    /*Authentication using variables*/
    Podio::authenticate_with_password($varUname, $varPword);

    /*GET ALL ORGANIZATIONS */
    $allOrgs = PodioOrganization::get_all();
    $a = 0;
    foreach ($allOrgs as $v)
    {
        $orgID = $allOrgs[$a]->org_id;
        echo " \n";
        /*GET ALL WORKSPACES */
        $allSpaces = PodioOrganization::get_all("/space/org/{org_id}/");
        $b = 0;
        foreach (($allSpaces[$a]->spaces) as $x)
        {
            $space_id = $allSpaces[$a]->spaces[$b]->space_id;
            $b++;

            try
            {
                /*GET ALL MEMBERS FOR EACH WORKSPACE */
                $team = PodioSpaceMember::get_all($space_id);
                $g = 0;

                foreach ($team as $s)
                {
                    /*Append each name and user_id */
                    $longString = $longString . ($team[$g]
                        ->profile->name . "#");
                    $g++;
                }
            }

            catch(PodioError $e)
            {
                print $e->body['error_description'];
            }

        }

        $a++;
    }

}

catch(PodioError $e)
{
    print $e->body['error_description'];
}

/*Split the longstring */
$string = $longString;
$str_arr = explode("#", $string);
/*Sort A-Z */
sort($str_arr);
/*Remove empty arrays */
$str_arr = array_filter($str_arr);

foreach ($str_arr as $ar)
{
    /*Upon splitting the long string, each array element is searched inside the new string holder. 
    If found, don't add it.
    If not found, add it on the shortstring list separated by '#' and a newline */
    $pos = strpos($shortString, $ar);
    if ($pos === false)
    {
        $shortString = $shortString . $ar . "#\n";
    }
    else
    {

    }
}
/*throw the shortstring - the new arraylist */
// print($shortString);



$str_arr = explode("#", $shortString);
/*Sort A-Z */
sort($str_arr);
/*Remove empty arrays */
$str_arr = array_filter($str_arr);
$longString = "";
foreach ($str_arr as $ar)
{  
     if (strtolower(trim($ar)) !== strtolower($varSentUname))
     {
         $longString = $longString . "0";
         
     }
     else
     {
        $longString = $longString . "1";
        break;
     }

}

print($longString);
?>
