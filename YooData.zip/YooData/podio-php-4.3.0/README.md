This the official PHP Client for interacting with the Podio API. All parts of the Podio API are covered in this client. See [podio.github.io/podio-php](http://podio.github.io/podio-php) for documentation.

[![Build Status](https://travis-ci.org/podio/podio-php.svg?branch=4.0.0)](https://travis-ci.org/podio/podio-php)


[![Join the chat at https://gitter.im/podio/podio-php](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/podio/podio-php?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)