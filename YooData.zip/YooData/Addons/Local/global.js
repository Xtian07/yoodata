document.getElementById("counter").innerHTML = localStorage["localNotifCounter"];

var curday = function (sp) {
    today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 11; //As January is 0.
    var yyyy = today.getFullYear();

    if (dd < 10) dd = '0' + dd;
    if (mm < 10) mm = '0' + mm;
    return (mm + sp + dd + sp + yyyy);
    //Sample output 06-03-2019
};




$('#formModal').modal('show');

$('.popover-dismiss').popover({
    trigger: 'focus'
})

// request permission on page load
document.addEventListener('DOMContentLoaded', function () {
    if (!Notification) {
        alert('Desktop notifications not available in your browser. Try Chromium.');
        return;
    }

    if (Notification.permission !== 'granted')
        Notification.requestPermission();
});


function PopupCenter(url, title, w, h) {
    // Fixes dual-screen position                         Most browsers      Firefox
    var dualScreenLeft = window.screenLeft != undefined ? window.screenLeft : window.screenX;
    var dualScreenTop = window.screenTop != undefined ? window.screenTop : window.screenY;

    var width = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width;
    var height = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : screen.height;

    var systemZoom = width / window.screen.availWidth;
    var left = (width - w) / 2 / systemZoom + dualScreenLeft
    var top = (height - h) / 2 / systemZoom + dualScreenTop
    var newWindow = window.open(url, title, 'scrollbars=no, width=' + w / systemZoom + ', height=' + h / systemZoom + ', top=' + top + ', left=' + left);

    // Puts focus on the newWindow
    // if (window.focus) 
    newWindow.focus();
}


function notifyMe() {
    if (Notification.permission !== 'granted')
        Notification.requestPermission();
    else {

        var notification = new Notification(getMsgWithHumor(), {
            icon: 'Images/yoonetlogo.png',
            body: 'Please supply information to YooTrack! ' + localStorage["localNotifCounter"],
            // // requireInteraction: true,
            image: 'Images/cat-wave.png'
        });

        notification.onclick = function () {
            event.preventDefault();
            // window.open('http://localhost/YooTrack/');

            // window.open("performer.html", "myWindow", 'width=800,height=600');
            PopupCenter('performer.html', 'xtf', '500', '600');
            // alert("Clicked!");
            window.focus();

            this.cancel();
            // window.close();

        };

        notification.onclose = function () {
            event.preventDefault();
            // window.open("performer.html", "myWindow", "resizable=no");
            PopupCenter('performer.html', 'xtf', '500', '600');
            // alert("Closed!");
            window.focus();

            this.cancel();
            // window.close();
        };

    }

}


var today = new Date();
var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();


if (localStorage["localSavedTimeMain"] !== curday('-')) {
    localStorage["localNotifCounter"] = "0";
    localStorage["localSavedTimeMain"] = curday('-');
}



// alert(time);
/**Run every 5 seconds */
window.setInterval(function () {

    if (localStorage["localNotifCounter"] < "3") {



        $.ajax(
            {
                type: "GET",
                url: 'http://192.168.1.43/YooTrack/index.html',
                success: function (data) {
                    // call your function here
                    notifyMe();

                    localStorage["localNotifCounter"] = parseInt(localStorage["localNotifCounter"]) + parseInt(1);
                    document.getElementById("counter").innerHTML = localStorage["localNotifCounter"];
                },
                error: function (xhr, statusText, err) {

                }
            });
        prevState = newState;


    }

}, 10000);


