var curday = function (sp) {
    today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //As January is 0.
    var yyyy = today.getFullYear();

    if (dd < 10) dd = '0' + dd;
    if (mm < 10) mm = '0' + mm;
    return (mm + sp + dd + sp + yyyy);
    //Sample output 06-03-2019
};

// alert(curday('-'));






/*CMD SUBMIT _CLICK*/
document.addEventListener('DOMContentLoaded', function () {
    var link = document.getElementById('btnSubmit');
    /* onClick's logic below:*/
    link.addEventListener('click', function () {
        window.close();
        // alert("CLOSE!");
    });
});

function getSupportCustomers() {


    $.ajax(
        {
            type: "GET",
            url: 'http://localhost/YooTrack/php/get-support-customers.php',
            success: function (data) {
                localStorage["localSupportClients"] = data;
                localStorage["localSavedTime"] = curday('-');


                var arrItems = data.split("|");
                arrItems.sort();

                for (var i = 0; i < arrItems.length; i++) {

                    if (arrItems[i] != "") {
                        $('#cboWorkspace').append('<option value="' + arrItems[i] + '">' + arrItems[i] + '</option>');
                    }

                }

            },
            error: function (xhr, statusText, err) {

            }
        });
}

if (localStorage["localSavedTime"] !== curday('-')) {
  
    getSupportCustomers();
}

else {
 
    var arrItems = localStorage["localSupportClients"].split("|");
    arrItems.sort();

    for (var i = 0; i < arrItems.length; i++) {

        if (arrItems[i] != "") {
            $('#cboWorkspace').append('<option value="' + arrItems[i] + '">' + arrItems[i] + '</option>');
        }

    }
}


