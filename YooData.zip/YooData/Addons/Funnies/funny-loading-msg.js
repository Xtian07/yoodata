/*List of loading messages */

function getMsgWithHumor(){
var msgWithHumor = 
["Hello folk!",
"You've been working hard!",
"May I interrupt?",
"It's me again ^_^",
"This is fast, I promise!",
"Click here to update YooTrack!",
"It's YooTrack n da haus!",
"Have a rest, take this one.",
"Thanks! Just one minute!",
"It's a good day, isn't it?",
"It's been a while!.",
"Here we go again.",
"Please bear with me.",
"I'm just a bot - don't get angry.",
"Don't worry, be happy!",
"...at least you're not on hold...",
"Hello, can you take this for me?",
"Why so serious?",
"Don't panic...",
"Keep calm and answer this.",
"Almost there!",
"We're testing your patience",
"As if you had any other choice",
"Attention!",
"Excuse me boss, you need to see this.", 
"You look familiar. Did you take this survey already?", 
"After this, I allow you to open Spotify.", 
"Don't know what to say. Just take this one.", 
"Work hard. Be nice.",
"Be nice. Work hard." 
];

return msgWithHumor = msgWithHumor[Math.floor(Math.random()*msgWithHumor.length)];

}
