semanticCustom();

/************Semantic UI script************/
function semanticCustom() {
    // $('.label.ui.dropdown')
    //     .dropdown();

    // $('.no.label.ui.dropdown')
    //     .dropdown({
    //         useLabels: false
    //     });


    $('#cboWorkspace')
        .dropdown()
        ;
        
    $('#cboType')
        .dropdown()
        ;




    ;

}





/*Add items to cboLabels Dynamically */
//var connectionItems = "Dynamic Label1|Dynamic Value1#Dynamic Label2|Dynamic Value2#";
//var arrItems = connectionItems.split("#");
//for (var i = 0; i < arrItems.length; i++) {
//    optNames = arrItems[i].split("|");
//    // $('#cboConnectionWrapper > > .menu').append('<div class="item" data-value="' + optNames[1] + '">' + optNames[0] + '</div>');
//    // $('#cboConnectionWrapper > > .menu').append('<option class="item" value="' + optNames[1] + '">' + optNames[0] + '</option>');
//    $('#cboConnection').append('<option value="' + optNames[1] + '">' + optNames[0] + '</option>');//WORKING EXAMPLE
//    
//
//    // $('.ui.dropdown')
//    //     .dropdown({
//    //         values: [
//    //             {
//    //                 name: 'Male',
//    //                 value: 'male'
//    //             }
//    //         ]
//    //     })
//    //     ;
//}




/*END********Semantic UI script************/

