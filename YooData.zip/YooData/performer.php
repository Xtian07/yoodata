<!DOCTYPE html>
<html lang="en">

<!--THIS IS THE DISPATCHER WEBSITE, IT WILL RANDOMLY OPENS A DESKTOP NOTIFICATION-->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>YooData</title>
    <link rel="shortcut icon" type="image/x-icon" href="Images/logo.png" />

    <!-- Semantic UI -->
    <link href="https://cdn.jsdelivr.net/npm/semantic-ui@2.2.13/dist/semantic.min.css" rel="stylesheet" />
    <script src="Addons/semantic-custom/jquery.min.js"></script>
    <script src="Addons/semantic-custom/semantic.min.js"></script>
    <link rel="stylesheet" href="Addons/semantic-custom/icon.min.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
    <!-- Bootstrap core CSS -->
    <link href="Addons/MDB-Free_4.8.1/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="Addons/MDB-Free_4.8.1/css/mdb.min.css" rel="stylesheet">
    <!-- Your custom styles (optional) -->
    <link href="Addons/MDB-Free_4.8.1/css/style.css" rel="stylesheet">

    <!-- Sweetalert Source -->
    <script src="Addons/Sweet-Alert-2/sweet-alert-2.js"></script>
    <!-- Funny Loading Message Source -->
    <script src="Addons/Funnies/funny-loading-msg.js"></script>

</head>

<style>
    * {
        font-family: 'Roboto', sans-serif;
    }

    html {
        overflow: hidden;
        margin: 0px;
    }

    body {
        background-image: url("Images/back.png");
        background-repeat: no-repeat;
        background-size: cover;
    }

    hr {
        display: block;
        height: 1px;
        border: 0;
        border-top: 1px solid #ccc;
        margin: 0em 0;
        padding: 0;
    }
</style>

<body>

    <div class="modal-dialog cascading-modal modal-avatar modal-sm " role="document" style="margin: 10px !important; margin-left: 50px !important; margin-right: 50px !important; margin-bottom: 0px !important; position: relative; padding: none !important;">
        <!--Content-->
        <img src="Images/yoodatahead.png" height="70px" style="float: right; padding: 10px;">
        <!-- <h3 class="mt-1 mb-2" style="color: white; text-align: center; font-weight: bold;">YooData</h3>
        <h6 class="mt-1 mb-2" style="color: white;  text-align: center;">Data makes the world go around!</h6> -->
        <div class="modal-content " style=" border-radius: 30px !important;  padding: none !important; margin: none !important; background-image: url('Images/team.png'); background-repeat: no-repeat; padding-bottom: 30px !important; ">

            <!--Header-->
            <div class="modal-header" style="height: 240px;">
                <!-- <img src="Images/yoonetlogo.png" alt="avatar" class="rounded-circle img-responsive" style="background-color: white;"> -->
            </div>
            <!--Body-->



            <div class="modal-body text-center mb-1" style="padding: 0px !important; margin: 0px !important;">




                <div id="divToRemove">
                    <img id="imgLoading" src="Images/loading.gif" style="height: 57px;  z-index: 1; padding: none; margin: 0px;" /><br>
                    <img id="imgLoadingCat" src="Images/FondCharmingAlbacoretuna-small.gif" style=" z-index: 2; height: 250px;" />
                </div>
                <div id="divBody" style="display: none; margin: none !important; padding: none !important; background: transparent !important;">



                    <div style="display: inline;border: 0px solid red; width: 100%; padding-left: 250px;">
                        <div id="divUser" style="text-transform:captialize; margin: 0px 0px 0px 0px !important; border: 0px solid red; padding: 0px 0px; display: inline;">Hi User</div>
                        &nbsp;&nbsp;|&nbsp;&nbsp;
                        <a id='divLogout' style="display: inline;border: 0px solid red; font-size: 10px;">LOG-OUT</a>
                    </div>

                    <div class="md-form ml-0 mr-0" style="margin: 0px !important;">
                        <!-- cboWorkspace Card -->
                        <div class="cardX winter-neva-gradientX" style="margin: 10px 40px; padding: none !important; margin-top: none !important;">

                            <!-- Card content -->
                            <div class="card-body hoverable" style="border-radius: 7px !important;">
                                <div class="indigo-text" style="text-align: left; "><i class="fas fa-briefcase"></i>&nbsp;&nbsp;What Business Are You Working On?</div>
                                <div id="cboWorkspaceWrapper" style="width: 100%; ">
                                    <select id="cboWorkspace" class="ui">
                                        <option value="">Pick a Client...</option>
                                    </select>
                                </div>
                            </div>

                        </div>
                        <!-- Card -->

                        <!-- cboType Card -->
                        <div class="cardX winter-neva-gradientX" style="margin: 10px 40px; padding: none !important; margin-top: none !important;">

                            <!-- Card content -->
                            <div class="card-body hoverable" style="border-radius: 7px !important;">
                                <div class="indigo-text" style="text-align: left;"><i class="fas fa-hammer"></i>&nbsp;&nbsp;What Type Of Work Are You Doing?</div>
                                <div id="cboTypeWrapper" style="width: 100%; ">
                                    <select id="cboType" class="ui">
                                        <option value="">Pick a Type of work...</option>
                                        
                                        <!-- NOTE! for the value, reference this from the Podio Category - because fetching categories is in sorted format-->
                                        <option disabled>** MANAGERS **</option>
                                        <option value="Administration">Administration</option>

                                        <option disabled>** DEVELOPMENT **</option>
                                        <option value="App Development">App Development</option>
                                        <option value="Podio Development">Podio Development</option>
                                        <option value="RPA Development">RPA Development</option>
                                        <option value="Web Development">Web Development</option>
                                        
                                        <option disabled>** SUPPORT **</option>
                                        <option value="Google Products">Google Products</option>
                                        <option value="Graphic Design">Graphic Design</option>
                                        <option value="Maintenance">Maintenance</option>
                                        <option value="Requests">Requests</option>
                                        <option value="SEO">SEO</option>                                        
                                        
                                        <option disabled>** TRAININGS **</option>
                                        <option value="Training - Client/Company Directed">Training - Client/Company Directed</option>
                                        <option value="Training - Self Directed">Training - Self Directed</option>
                                        
                                        <option disabled>** OPEN **</option>
                                        <option value="Idle - Awaiting Tasks">Idle - Awaiting Tasks</option>
                                        
 
                                    </select>
                                </div>
                            </div>

                        </div>
                        <!-- Card -->


                        <div style="width: 100%; margin: none; padding: 10px;">
                            <button id="btnSubmit" class="btn mt-1" style="border-radius: 30px !important; color: white; background-color: #80ACC4; background-image: linear-gradient(to right, #80ACC4 , #CBC2C3);">Submit <i class="fas fa-sign-in ml-1"></i></button>
                        </div>

                    </div>
                </div>

            </div>
            <!--/.Content-->
        </div>

        <!--JAVASCRIPT-->
        <script>
            if (localStorage.getItem("localBusiness") == null) {
                localStorage.setItem("localBusiness", "");
            }

            if (localStorage.getItem("localType") == null) {
                localStorage.setItem("localType", "");
            }
            if (localStorage.getItem("localTypeIndex") == null) {
                localStorage.setItem("localTypeIndex", "");
            }
            if (localStorage.getItem("localUser") == null) {
                localStorage.setItem("localUser", "");
            }


            var siteIndex = "http://localhost/YooData/";
            var data = localStorage.getItem("localSupportClients");
            var intAddedToMonth = 1;
            var localBusiness = localStorage.getItem("localBusiness");
            var localWork = localStorage.getItem("localType");
            var localWorkIndex = localStorage.getItem("localTypeIndex");
            var localUser = localStorage.getItem("localUser");



            // document.getElementById("divUser").innerHTML = "Hi " + localUser + "!";
            // alert(localStorage.getItem("localUser"));
            checkIfUsernameIsEmpty();

            /**If user is empty/undefined */
            function checkIfUsernameIsEmpty() {

                // alert(localStorage.getItem("localUser"));
                if (localStorage.getItem("localUser") == "" || localStorage.getItem("localUser") == "User") {
                    // alert(localStorage.getItem("localUser"));

                    const ipAPI = 'https://api.ipify.org?format=json'

                    const {
                        value: ipAddress
                    } = Swal.fire({
                        title: 'Enter your Podio name first.',
                        input: 'text',
                        inputValue: "",
                        showCancelButton: false,
                        // showLoaderOnConfirm: true,
                        allowOutsideClick: false,
                        inputValidator: (value) => {
                            if (!value) {
                                return 'You need to write something!'
                            } else {
                                //condition 
                                $.ajax({
                                    /*Variables to be sent */
                                    data: {
                                        varEmpName: value
                                    },
                                    /*Server-side PHP */
                                    url: siteIndex + 'PHP/get-team-names.php',
                                    method: 'POST',
                                    /*the variable replied by the server stored in string */
                                    success: function(strResponse) {

                                        // alert(strResponse);

                                        if (parseInt(strResponse.trim()) < "1") {
                                            Swal.fire({
                                                type: 'error',
                                                title: 'Oh no!',
                                                text: "Username not found. Please try again.",
                                                allowOutsideClick: false,
                                            }).then((result) => {
                                                checkIfUsernameIsEmpty();
                                                if (result.value) {
                                                    // window.close();
                                                }
                                            })
                                        } else {


                                            localUser = value;
                                            localStorage.setItem("localUser", localUser);


                                            document.getElementById("divToRemove").style.display = "none";
                                            document.getElementById("divBody").style.display = "block";
                                            document.getElementById("divUser").innerHTML = "Hi " + localUser + "!";
                                            // Swal.fire({
                                            //     type: 'success',
                                            //     title: 'Great!',
                                            //     text: "Thanks for the response.",
                                            //     allowOutsideClick: false,
                                            // }).then((result) => {
                                            //     if (result.value) {
                                            //         window.close();
                                            //     }
                                            // })
                                        }
                                    }
                                }).fail(function(strResponse) {

                                    Swal.fire({
                                        type: 'error',
                                        title: 'Oh no!',
                                        text: "Fail to check username. Please try again.",
                                        allowOutsideClick: false,
                                    }).then((result) => {
                                        if (result.value) {
                                            // window.close();
                                        }
                                    })

                                });
                            }
                        }
                    })


                } else {
                    document.getElementById("divToRemove").style.display = "none";
                    document.getElementById("divBody").style.display = "block";
                    document.getElementById("divUser").innerHTML = "Hi " + localUser + "!";
                }
            }


            /**-------------------------- */
            /**Function to Propercase strings */

            /**-------------------------- */

            /*CMD SUBMIT _CLICK*/
            document.addEventListener('DOMContentLoaded', function() {
                var link = document.getElementById('btnSubmit');
                /* onClick's logic below:*/
                link.addEventListener('click', function() {

                    localStorage.setItem("localBusiness", $("#cboWorkspace option:selected").text());
                    localStorage.setItem("localType", $("#cboType option:selected").text());
                    localStorage.setItem("localTypeIndex", $("#cboType option:selected").index());

                    if ($("#cboType option:selected").text() == "Administration") {
                        localStorage.setItem("localTypeIndex", "13");
                    }

                    if ($("#cboType option:selected").text() == "App Development") {
                        localStorage.setItem("localTypeIndex", "1");
                    }
                    if ($("#cboType option:selected").text() == "Podio Development") {
                        localStorage.setItem("localTypeIndex", "5");
                    }
                    if ($("#cboType option:selected").text() == "RPA Development") {
                        localStorage.setItem("localTypeIndex", "7");
                    }
                    if ($("#cboType option:selected").text() == "Web Development") {
                        localStorage.setItem("localTypeIndex", "9");
                    }
                    if ($("#cboType option:selected").text() == "Google Products") {
                        localStorage.setItem("localTypeIndex", "2");
                    }
                    if ($("#cboType option:selected").text() == "Graphic Design") {
                        localStorage.setItem("localTypeIndex", "3");
                    }
                    if ($("#cboType option:selected").text() == "Maintenance") {
                        localStorage.setItem("localTypeIndex", "4");
                    }
                    if ($("#cboType option:selected").text() == "Requests") {
                        localStorage.setItem("localTypeIndex", "6");
                    }
                    if ($("#cboType option:selected").text() == "SEO") {
                        localStorage.setItem("localTypeIndex", "8");
                    }
                    if ($("#cboType option:selected").text() == "Training - Self Directed") {
                        localStorage.setItem("localTypeIndex", "10");
                    }
                    if ($("#cboType option:selected").text() == "Training - Client/Company Directed") {
                        localStorage.setItem("localTypeIndex", "11");
                    }
                    if ($("#cboType option:selected").text() == "Idle - Awaiting Tasks") {
                        localStorage.setItem("localTypeIndex", "12");
                    }

                    // if ($("#cboType option:selected").index() >= 2 || $("#cboType option:selected").index() <=5){
                    //     localStorage.setItem("localTypeIndex", ($("#cboType option:selected").index()) - 1);
                    //     alert("this");
                    // }
                    // alert(localStorage.getItem("localNotifCounter"));

                    /**If no business was selected */
                    if (localStorage.getItem("localBusiness") == "" || localStorage.getItem("localBusiness") == "Pick a Client...") {
                        showToast('error', "Please select a Business!", '#FBC4B6', 'bottom-end');
                    }

                    /**If no type of work was selected */
                    else if (localStorage.getItem("localType") == "" || localStorage.getItem("localType") == "Pick a Type of work...") {
                        showToast('error', "Please select a Type of Work!", '#FBC4B6', 'bottom-end');
                    }

                    /**If no Badge Counter (local notif counter) */
                    else if (localStorage.getItem("localNotifCounter") == null) {
                        localStorage.setItem("localNotifCounter", "1");
                    }

                    /**Complete entry */
                    else {

                        document.getElementById("divToRemove").style.display = "block";
                        document.getElementById("divBody").style.display = "none";

                        $.ajax({
                            /*Variables to be sent */
                            data: {
                                varEmpName: localUser,
                                varCurClient: localStorage.getItem("localBusiness"),
                                varType: localStorage.getItem("localTypeIndex"),
                                varBadge: localStorage.getItem("localNotifCounter")
                            },
                            /*Server-side PHP */
                            url: siteIndex + 'PHP/conn.php',
                            method: 'POST',
                            /*the variable replied by the server stored in string */
                            success: function(strResponse) {

                                Swal.fire({
                                    type: 'success',
                                    title: 'Great!',
                                    text: "Thanks for the response. " + strResponse,
                                    allowOutsideClick: false,
                                }).then((result) => {
                                    if (result.value) {
                                        window.close();
                                        document.getElementById("divToRemove").style.display = "none";
                                        document.getElementById("divBody").style.display = "block";
                                    }
                                })
                            }
                        }).fail(function(strResponse) {

                            Swal.fire({
                                type: 'error',
                                title: 'Oh no!',
                                text: "Fail to submit result. Please try again.",
                                allowOutsideClick: false,
                            }).then((result) => {
                                if (result.value) {
                                    // window.close();
                                    document.getElementById("divToRemove").style.display = "none";
                                    document.getElementById("divBody").style.display = "block";
                                }
                            })

                        });


                    }







                    // window.close();
                    // alert("CLOSE!");
                });
            });

            /*LOG-OUT _CLICK*/
            document.addEventListener('DOMContentLoaded', function() {
                var link = document.getElementById('divLogout');
                /* onClick's logic below:*/
                link.addEventListener('click', function() {
                    // alert("log-out");
                    localStorage.setItem("localUser", "");
                    checkIfUsernameIsEmpty();
                    // localUser = "";
                    document.getElementById("divToRemove").style.display = "block";
                    document.getElementById("divBody").style.display = "none";


                });
            });





            /**Function to get current date */
            var curday = function(sp) {
                today = new Date();
                var dd = today.getDate();
                var mm = today.getMonth() + parseInt(intAddedToMonth); //As January is 0. intAddedToMonth should always be equal to 1.
                var yyyy = today.getFullYear();

                if (dd < 10) dd = '0' + dd;
                if (mm < 10) mm = '0' + mm;
                return (mm + sp + dd + sp + yyyy);
                //Sample output 06-03-2019
                // YYYY-MM-DD HH:MM:SS
            };
            /**End of Function */



            function getSupportCustomers() {
                data = "";

                /*Loading screen while processing on the background */
                let timerInterval
                Swal.fire({
                    title: 'Loading...',
                    html: '<strong></strong><img id="imgLoadingCat" src="Images/FondCharmingAlbacoretuna-small.gif" />',
                    timer: 4000,
                    allowOutsideClick: false,
                    onBeforeOpen: () => {
                        Swal.showLoading()
                        timerInterval = setInterval(() => {
                            Swal.getContent().querySelector('strong')
                                .textContent = "Fetching data from server..."
                        }, 1000 /*Every 2 seconds */ )
                    },
                    onClose: () => {
                        clearInterval(timerInterval)
                    }
                }).then((result) => {
                    if (result.dismiss === Swal.DismissReason.timer) {
                        console.log('I was closed by the timer')
                    }
                });

                data = <?php
                        $longString = "";
                        $shortString = "";

                        /*#This is important*/
                        require_once('podio-php-4.3.0/PodioAPI.php');
                        $client_id = "plugin";
                        $client_secret = "4zPdYzs9UEfPRPRXqJm9Y82GBejO07DVoNNduhMbNzIdmqPs7zbQnl2GRb4vcrQp";
                        Podio::setup($client_id, $client_secret);
                        /*#End of important*/

                        $app_id = "17654354"; //this is for the customers app //19146567//this is for the support app
                        $app_token = "66016adf626642fe859dd858f86ebc77"; //"348ee6d821d448fbaa8a630a6ad18632";
                        try {
                            Podio::authenticate_with_app($app_id, $app_token);
                            // Authentication was a success, now you can start making API calls.
                            $items = PodioItem::filter($app_id, $attributes = array(
                                "limit" => 100,
                            ), $options = array());

                            foreach ($items as $x) {
                                if ($longString == "") {
                                    $longString = $x->title . "|";
                                } else {
                                    $longString = $longString . $x->title . "|";
                                }
                            }

                            $longString = $longString . "Yoonet (Internal)" . "|";
                        } catch (PodioError $e) {
                            // Something went wrong. Examine $e->body['error_description'] for a description of the error.
                            print_r($e);
                        }

                        $shortString = '"' . $longString . '"';

                        echo $shortString;
                        ?>;

                localStorage.setItem("localSupportClients", data);

            }

            /**If the date is different OR the variable Clients has no data
             * Fetch data
             */
            if (localStorage.getItem("localSavedTime") !== curday('-') || localStorage.getItem("localSupportClients") == null) {
                localStorage.setItem("localSavedTime", curday('-'));
                getSupportCustomers();
                checkIfUsernameIsEmpty();


            }


            /**Load the client names on combo box */
            var arrItems = data.split("|");
            arrItems.sort();

            for (var i = 0; i < arrItems.length; i++) {

                if (arrItems[i] != "") {
                    $('#cboWorkspace').append('<option value="' + arrItems[i] + '">' + arrItems[i] + '</option>');
                }
            }
            $('#cboWorkspace').dropdown('set selected', localBusiness).dropdown('set text', localBusiness);
            $('#cboType').dropdown('set selected', localWork).dropdown('set text', localWork);

            // document.getElementById("divToRemove").style.display = "none";
            // document.getElementById("divBody").style.display = "block";

            function titleCase(str) {

                str = str.toLowerCase().split(' ');

                let final = [];

                for (let word of str) {
                    final.push(word.charAt(0).toUpperCase() + word.slice(1));
                }

                return final.join(' ')

            }


            /**End of Load client names */

            /*TOAST! */
            function showToast(strType, strTitle, strColor, strPosition) {
                const Toast = Swal.mixin({
                    toast: true,
                    position: strPosition,
                    /*'top-end', */
                    showConfirmButton: false,
                    background: strColor,
                    /*'#EAF8EA',*/
                    timer: 4000
                });
                Toast.fire({
                    type: strType,
                    /*'success',*/
                    title: strTitle /*'Hello there my friend! You clicked on the right spot! Have a good day!'*/
                })
            }
            /*END OF TOAST! */
        </script>
        <!--END OFJAVASCRIPT-->

        <!-- <script type="text/javascript" src="Addons\Local\global.js"></script> -->
        <script src="Addons/semantic-custom/semantic-custom.js"></script>
        <!-- SCRIPTS -->
        <!-- JQuery -->
        <script type="text/javascript" src="Addons/MDB-Free_4.8.1/js/jquery-3.4.0.min.js"></script>
        <!-- Bootstrap tooltips -->
        <script type="text/javascript" src="Addons/MDB-Free_4.8.1/js/popper.min.js"></script>
        <!-- Bootstrap core JavaScript -->
        <script type="text/javascript" src="Addons/MDB-Free_4.8.1/js/bootstrap.min.js"></script>
        <!-- MDB core JavaScript -->
        <script type="text/javascript" src="Addons/MDB-Free_4.8.1/js/mdb.min.js"></script>




</body>

</html>