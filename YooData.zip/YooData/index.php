<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>YooData</title>
    <link rel="shortcut icon" type="image/x-icon" href="Images/logo_with_background.png" />

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
    <!-- MDB-->
    <link href="Addons/MDB-Free_4.8.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="Addons/MDB-Free_4.8.1/css/mdb.min.css" rel="stylesheet">
    <link href="Addons/MDB-Free_4.8.1/css/style.css" rel="stylesheet">

    <script src="Addons/Funnies/funny-loading-msg.js"></script>
    <!-- Sweetalert Source -->
    <script src="Addons/Sweet-Alert-2/sweet-alert-2.js"></script>
    <!-- Funny Loading Message Source -->
    <script src="Addons/Funnies/funny-loading-msg.js"></script>
    <!-- <script src="Addons/Funnies/welcome-msg.js"></script> -->




</head>

<nav class="navbar fixed-top navbar-expand-lg navbar-dark scrolling-navbar" style="background-image: linear-gradient(to right, rgba(128, 172, 196, 0.9) , rgba(203, 194, 195, 0.5), rgba(128, 172, 196, 0.9));">
    <a class="navbar-brand" href="#"><img src="Images/logo.png" style="height: 30px;"><img src="Images/title.png" style="height: 30px;"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#" id="btnAbout">About</a>
            </li>

        </ul>
    </div>

    <ul class="nav navbar-nav nav-flex-icons ml-auto">


        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="txtName" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-user"></i>
                Hi
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                <a class="dropdown-item" href="#" id="txtLog">Log-out</a>
            </div>
        </li>
    </ul>
</nav>


<body style="background: url('Images/desktop.png'); background-repeat: no-repeat; background-size: cover; overflow: hidden;">
    <div id="divTime" style="display: none;"></div>
    <div style="display: none; ">
        <div>Old Date:
            <div id="oldDate"></div>
        </div>
        <div>Current Date:
            <div id="currentDate"></div>
        </div>
        <div>int Counter:
            <div id="counter">0</div>
        </div>
        <div>Uptime in seconds:
            <div id="pamilang">0</div>
        </div>
    </div>

    <script src="Addons/sketch/js/sketch.js"></script>
    <!--JAVASCRIPT-->
    <script>
        /**This is the configuration*/
        // var siteIndex = "https://yootracker.000webhostapp.com";
        // var sitePerformer = "https://yootracker.000webhostapp.com/performer.php";

        var siteIndex = "https://yoodata.netlify.com/";
        var sitePerformer = "https://yoodata.netlify.com/performer.php";
        var intAddedToMonth = 1;
 

        if (localStorage.getItem("localUser") == null || localStorage.getItem("localUser") == "User" || localStorage.getItem("localUser") == "") {
            document.getElementById("txtName").innerHTML = "<i class=\"fas fa-user\"></i>  Hi User";
            document.getElementById("txtLog").innerHTML = "Log-in";
        } else {
            document.getElementById("txtName").innerHTML = "<i class=\"fas fa-user\"></i>  Hi " + localStorage.getItem("localUser");
            document.getElementById("txtLog").innerHTML = "Log-out";
        }


        var strName = localStorage.getItem("localUser");
        

        if (localStorage.getItem("localArrTime") == null) {
            localStorage.setItem("localArrTime", getRandomTime().split(","));
        }
        var arrTime = localStorage.getItem("localArrTime").split(",");
        alert(arrTime);



        /**End of configuration*/

        /**request permission on page load================================================*/
        document.addEventListener('DOMContentLoaded', function() {
            if (!Notification) {
                alert('Desktop notifications not available in your browser. Try Chromium.');
                return;
            }

            if (Notification.permission !== 'granted')
                Notification.requestPermission();
        });
        /**END of request permission on page load*/

        /**function to get Current Date================================================*/
        var curday = function(sp) {
            today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth() + parseInt(intAddedToMonth); //As January is 0.
            var yyyy = today.getFullYear();

            if (dd < 10) dd = '0' + dd;
            if (mm < 10) mm = '0' + mm;
            return (mm + sp + dd + sp + yyyy);
            //Sample output 06-03-2019
        };
        /**END of function to get Current Date*/

        /**function to Create Pop-up Window================================================*/
        function PopupCenter(url, title, w, h) {
            // Fixes dual-screen position                         Most browsers      Firefox
            var dualScreenLeft = window.screenLeft != undefined ? window.screenLeft : window.screenX;
            var dualScreenTop = window.screenTop != undefined ? window.screenTop : window.screenY;
            var width = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width;
            var height = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : screen.height;
            var systemZoom = width / window.screen.availWidth;
            var left = (width - w) / 2 / systemZoom + dualScreenLeft
            var top = (height - h) / 2 / systemZoom + dualScreenTop
            var newWindow = window.open(url, title, 'scrollbars=no, width=' + w / systemZoom + ', height=' + h / systemZoom + ', top=' + top + ', left=' + left);
            newWindow.focus();
        }
        /**End of function to Create Pop-up Window*/

        /**function to Create Desktop Notification================================================*/
        function notifyMe() {

            if (Notification.permission !== 'granted') {
                alert("Please grant permission or allow notifications!\nAlso, don't open this page in an Incognito Window.\nThank you folks! ^_^");
                Notification.requestPermission();
            } else {

                var notification = new Notification(getMsgWithHumor(), {
                    icon: 'Images/logo.png',
                    body: 'Please supply information to YooData! ' + "Notification# " + (parseInt(localStorage["localNotifCounter"]) + 1),
                    // // requireInteraction: true,
                    image: 'Images/hi.png'
                    // image: 'Images/FondCharmingAlbacoretuna-small.gif'
                });

                notification.onclick = function() {
                    event.preventDefault();
                    // window.open('http://localhost/YooTrack/');
                    // window.open("performer.html", "myWindow", 'width=800,height=600');
                    PopupCenter(sitePerformer, 'xtf', '500', '600');
                    // alert("Clicked!");
                    window.focus();
                    this.cancel();
                    // window.close();
                };

                notification.onclose = function() {
                    event.preventDefault();
                    // window.open("performer.html", "myWindow", "resizable=no");
                    PopupCenter(sitePerformer, 'xtf', '500', '600');
                    window.focus();
                    this.cancel();
                    // window.close();
                };

                notification.onshow = function() {
                    setTimeout(function() {
                        notification.close()
                    }, 3000);
                };
            }
        }
        /**END of function to Create Desktop Notification*/


        document.getElementById("oldDate").innerHTML = localStorage["localSavedTimeMain"];
        document.getElementById("currentDate").innerHTML = curday('-');

        var today = new Date();
        var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();

        /**Condition: if saved time <> current time, reset notifcounter*/
        if (localStorage["localSavedTimeMain"] !== curday('-')) {
            localStorage["localNotifCounter"] = "0";
            localStorage["localSavedTimeMain"] = curday('-');
            arrTime = getRandomTime().split(",");
            localStorage["localArrTime"] = arrTime;
        }

        /**-------------------------------------------------------------------*/
        /**Run every random seconds */
        window.setInterval(function() {
            // notifyMe();
        }, 3000);
        /**-------------------------------------------------------------------*/

        var intPamilang = 0;
        var innerCounter = 0;
        window.setInterval(function() {
            intPamilang = intPamilang + 1;
            innerCounter = innerCounter + 1;
            document.getElementById("pamilang").innerHTML = intPamilang;
            document.getElementById("counter").innerHTML = localStorage["localNotifCounter"];

            var dtNow = new Date();
            var strDtNow = dtNow.getHours() + ":" + dtNow.getMinutes() + ":" + dtNow.getSeconds();

            /**Condition for the Random Time of Notification */
            for (i = 0; i < arrTime.length; i++) {
                // document.getElementById("divTime").innerHTML = document.getElementById("divTime").innerHTML + "<br>" + arrTime[i];
                if (arrTime[i] == strDtNow) {
                    // alert("Show Now!\nRnd: " + arrTime[i] + "\nNow: " + strDtNow);

                    /**Condition: If notifcounter is less than 8, show desktop notification*/
                    if (parseInt(localStorage["localNotifCounter"]) < parseInt(8)) {
                        $.ajax({
                            type: "GET",
                            url: siteIndex,
                            success: function(data) {
                                notifyMe();
                                localStorage["localNotifCounter"] = parseInt(localStorage["localNotifCounter"]) + parseInt(1);
                                document.getElementById("counter").innerHTML = localStorage["localNotifCounter"];
                                innerCounter = 0;
                            },
                            error: function(xhr, statusText, err) {}
                        });
                    } /**End of if 2 */
                } /**End of if 1 */
            } /**End of for */

        }, 1000);

        /**------------------------------------------------------------------ */

        /**SHOW ALL THE RANDOM TIME */
        for (i = 0; i < arrTime.length; i++) {
            document.getElementById("divTime").innerHTML = document.getElementById("divTime").innerHTML + "<br>" + arrTime[i];
        }
        // alert("PO " + arrTime);
        var dtNow = new Date();
        var strDtNow = dtNow.getHours() + ":" + dtNow.getMinutes() + ":" + dtNow.getSeconds();



        /**------------------------------------------------------------------ */
        function getRandomTime() {
            var timeToReturn = "";
            /**
                Set the hours
                */
            var Counter = 0;
            var arrHR = ["7", "8", "9", "10", "12", "13", "14", "15"];

            while (Counter !== 8) {
                Counter++;
            }

            /**
            Compute the minutes
            */
            Counter = 0;
            var mnMin = 11;
            var mnMax = 50;
            var arrMN = [];

            while (Counter !== 8) {
                Counter++;
                random = Math.random() * (+mnMax - +mnMin) + +mnMin;
                arrMN.push(random);
            }
            // arrMN.sort((a, b) => a - b);

            /**
            Compute the seconds
            */
            Counter = 0;
            var scMin = 11;
            var scMax = 50;
            var arrSC = [];

            while (Counter !== 8) {
                Counter++;
                random = Math.random() * (+scMax - +scMin) + +scMin;
                arrSC.push(random);
            }
            arrSC.sort((a, b) => a - b);


            for (i = 0; i < 8; i++) {
                // document.write("\nTIME " + (i + 1) + ": " + arrHR[i] + ":" + parseInt(arrMN[i]) + ":" + parseInt(arrSC[i]) + "<br>");
                timeToReturn = timeToReturn + arrHR[i] + ":" + parseInt(arrMN[i]) + ":" + parseInt(arrSC[i]) + ",";
            }

            return timeToReturn.slice(0, -1);;


        }












        // ----------------------------------------
        // Particle
        // ----------------------------------------

        function Particle(x, y, radius) {
            this.init(x, y, radius);
        }

        Particle.prototype = {

            init: function(x, y, radius) {

                this.alive = true;

                this.radius = radius || 10;
                this.wander = 0.15;
                this.theta = random(TWO_PI);
                this.drag = 0.92;
                this.color = '#90adbf';

                this.x = x || 0.0;
                this.y = y || 0.0;

                this.vx = 0.0;
                this.vy = 0.0;
            },

            move: function() {

                this.x += this.vx;
                this.y += this.vy;

                this.vx *= this.drag;
                this.vy *= this.drag;

                this.theta += random(-0.5, 0.5) * this.wander;
                this.vx += sin(this.theta) * 0.1;
                this.vy += cos(this.theta) * 0.1;

                this.radius *= 0.991;
                this.alive = this.radius > 0.0001;
            },

            draw: function(ctx) {

                ctx.beginPath();
                ctx.arc(this.x, this.y, this.radius, 0, TWO_PI);
                ctx.fillStyle = this.color;
                ctx.fill();
            }
        };

        // ----------------------------------------
        // Example
        // ----------------------------------------

        var MAX_PARTICLES = 580;
        var COLOURS = ['#77a3bc', '#e7d4ce', '#ffffff', '#c6c4c9', '#efd8d0', '#51829c', '#2f586d'];

        var particles = [];
        var pool = [];

        var demo = Sketch.create({
            container: document.getElementById('container'),
            retina: 'auto'
        });

        demo.setup = function() {

            // Set off some initial particles.
            var i, x, y;

            for (i = 0; i < 20; i++) {
                x = (demo.width * 0.5) + random(-100, 100);
                y = (demo.height * 0.5) + random(-100, 100);
                demo.spawn(x, y);
            }
        };

        demo.spawn = function(x, y) {

            var particle, theta, force;

            if (particles.length >= MAX_PARTICLES)
                pool.push(particles.shift());

            particle = pool.length ? pool.pop() : new Particle();
            particle.init(x, y, random(5, 40));

            particle.wander = random(0.5, 2.0);
            particle.color = random(COLOURS);
            particle.drag = random(0.9, 0.99);

            theta = random(TWO_PI);
            force = random(2, 8);

            particle.vx = sin(theta) * force;
            particle.vy = cos(theta) * force;

            particles.push(particle);
        };

        demo.update = function() {

            var i, particle;

            for (i = particles.length - 1; i >= 0; i--) {

                particle = particles[i];

                if (particle.alive) particle.move();
                else pool.push(particles.splice(i, 1)[0]);
            }
        };

        demo.draw = function() {

            demo.globalCompositeOperation = 'lighter';

            for (var i = particles.length - 1; i >= 0; i--) {
                particles[i].draw(demo);
            }
        };

        demo.mousemove = function() {

            var particle, theta, force, touch, max, i, j, n;

            for (i = 0, n = demo.touches.length; i < n; i++) {

                touch = demo.touches[i], max = random(1, 4);
                for (j = 0; j < max; j++) {
                    demo.spawn(touch.x, touch.y);
                }

            }
        };


        /*ABOUT _CLICK*/
        document.addEventListener('DOMContentLoaded', function() {
            var link = document.getElementById('btnAbout');
            /* onClick's logic below:*/
            link.addEventListener('click', function() {


                Swal.fire(
                    'Data, data, so many data!',
                    '<div><b>About YooData</b></div>\nYooData is a Data Gathering Tool to have a clearer Data Analysis of the tasks and clients relation to each other to get a more sound and logical enterpretation. It aims to maximize employees time and be more productive while understanding and monitoring the time our clients consume.',
                    // '<div><b>About YooData</b></div>\nYooData aims to maximize your time and be more productive. By means of gathering input data, YooData analyzes information and shows a meaningful result for analysts to decide accordingly.',
                    'info'
                )

            });

        });

        /*LOG_CLICK*/
        document.addEventListener('DOMContentLoaded', function() {
            var link = document.getElementById('txtLog');
            /* onClick's logic below:*/
            link.addEventListener('click', function() {

                if (localStorage.getItem("localUser") == "User") {

                    const ipAPI = 'https://api.ipify.org?format=json'

                    const {
                        value: ipAddress
                    } = Swal.fire({
                        title: 'Enter your Podio name first.',
                        input: 'text',
                        inputValue: "",
                        showCancelButton: false,
                        // showLoaderOnConfirm: true,
                        allowOutsideClick: false,
                        inputValidator: (value) => {
                            if (!value) {
                                return 'You need to write something!'
                            } else {
                                //condition 
                                $.ajax({
                                    /*Variables to be sent */
                                    data: {
                                        varEmpName: value
                                    },
                                    /*Server-side PHP */
                                    url: siteIndex + 'PHP/get-team-names.php',
                                    method: 'POST',
                                    /*the variable replied by the server stored in string */
                                    success: function(strResponse) {

                                        // alert(strResponse);

                                        if (parseInt(strResponse.trim()) < "1") {
                                            Swal.fire({
                                                type: 'error',
                                                title: 'Oh no!',
                                                text: "Username not found. Please try again.",
                                                allowOutsideClick: false,
                                            }).then((result) => {
                                                checkIfUsernameIsEmpty();
                                                if (result.value) {
                                                    // window.close();
                                                }
                                            })
                                        } else {

                                           
                                            strName = value;
                                            localStorage.setItem("localUser", strName);
                                            document.getElementById("txtName").innerHTML = "<i class=\"fas fa-user\"></i>  Hi " + strName;
                                            document.getElementById('txtLog').innerHTML = "Log-out";
                                            alert(localStorage.getItem("localUser"));
                                        }
                                    }
                                }).fail(function(strResponse) {

                                    Swal.fire({
                                        type: 'error',
                                        title: 'Oh no!',
                                        text: "Fail to check username. Please try again.",
                                        allowOutsideClick: false,
                                    }).then((result) => {
                                        if (result.value) {
                                            // window.close();
                                        }
                                    })

                                });
                            }
                        }
                    })
                } else {
                    localStorage.setItem("localUser","User");
                    strName = "User";
                    document.getElementById("txtName").innerHTML = "<i class=\"fas fa-user\"></i>  Hi User";
                    document.getElementById('txtLog').innerHTML = "Log-in";

                }


            });
        });
    </script>
    <!--END OF JAVASCRIPT-->
    <script type="text/javascript" src="Addons/MDB-Free_4.8.1/js/jquery-3.4.0.min.js"></script>
    <script type="text/javascript" src="Addons/MDB-Free_4.8.1/js/popper.min.js"></script>
    <script type="text/javascript" src="Addons/MDB-Free_4.8.1/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="Addons/MDB-Free_4.8.1/js/mdb.min.js"></script>
</body>

</html>